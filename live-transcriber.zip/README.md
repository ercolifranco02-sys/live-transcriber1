# Live Transcriber

Proyecto mínimo para transcripción en vivo desde el navegador usando AssemblyAI (o servicio STT similar).

## Archivos
- `server.js` - backend Node.js que sirve la web y proxifica WebSocket al servicio STT.
- `public/index.html` - frontend que captura micrófono y envía audio en tiempo real.
- `.env.example` - ejemplo de variable de entorno.
- `package.json` - dependencias y script de inicio.

## Configuración local
1. Clonar o descargar este proyecto.
2. Copiar `.env.example` a `.env` y poner tu `ASSEMBLYAI_API_KEY`.
3. Instalar dependencias:
   ```
   npm install
   ```
4. Ejecutar:
   ```
   node server.js
   ```
5. Abrir en el navegador `http://localhost:3000` y darle a *Iniciar*.

## Deploy (Railway / Render / Heroku)
1. Subir el repo a GitHub.
2. Crear un nuevo proyecto en Railway (o Render) y hacer deploy desde el repo.
3. Agregar la variable de entorno `ASSEMBLYAI_API_KEY` en el panel del servicio.
4. Si tu deploy usa HTTPS, el frontend se conectará por `wss://`.

## Nota importante
- Dependiendo del proveedor STT (AssemblyAI, Deepgram, Google, etc.), puede ser necesario adaptar el formato de los frames que se envían al servicio (por ejemplo, base64 dentro de JSON, o frames binarios específicos). Revisá la documentación del servicio elegido y, si querés, yo adapto el servidor para que cumpla exactamente ese formato.
