import express from 'express';
import WebSocket from 'ws';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
app.use(express.static('public'));

const server = app.listen(process.env.PORT || 3000, () => {
  console.log(`Servidor en puerto ${process.env.PORT || 3000}`);
});

const wss = new WebSocket.Server({ server });

wss.on('connection', (clientWS) => {
  console.log('Cliente conectado');

  // Conectar al WebSocket de AssemblyAI en modo "realtime".
  // Nota: revisá la documentación de AssemblyAI Realtime para confirmar
  // el handshake / formato exacto de frames (text/binary, base64, etc.)
  // y agregar los eventos adicionales que necesites (p. ej. configuración).
  const aaiWS = new WebSocket(
    `wss://api.assemblyai.com/v2/realtime/ws?sample_rate=16000`,
    { headers: { Authorization: process.env.ASSEMBLYAI_API_KEY } }
  );

  aaiWS.on('open', () => console.log('Conectado a AssemblyAI'));
  aaiWS.on('message', (msg) => {
    // Reenviar la transcripción al cliente tal cual la recibe AssemblyAI.
    clientWS.send(msg.toString());
  });

  aaiWS.on('error', (err) => {
    console.error('AssemblyAI WS error:', err);
    clientWS.send(JSON.stringify({ error: 'AssemblyAI connection error' }));
  });

  clientWS.on('message', (msg) => {
    // Reenviar audio binario desde el cliente hacia AssemblyAI.
    // Dependiendo del requerimiento de AssemblyAI, puede ser necesario
    // envolver en JSON o enviar como base64. Probar y adaptar si hace falta.
    aaiWS.send(msg);
  });

  clientWS.on('close', () => {
    try { aaiWS.close(); } catch(e) {}
  });
});
